import os
import shutil
import webbrowser
import fnmatch
from utils import log, normalize
from ziptools import find_existing_zip, extract_archive, download_from_url, download_from_nexus
from installers import (
    install_root_flattened,
    install_lml_hybrid,
    install_secondary,
)
from exeinstaller import install_exe_mod   # <-- EXE MODULE


class Mod:
    def __init__(self, name, mod_type, folder=None, target=None,
                 nexus_url=None, download_url=None,
                 secondary=None, blacklist=None, regex_blacklist=None,
                 manual=False, no_download=False, force_download=False,
                 prefer_fallback_zip=False, dry_run=False, summary=False,
                 flatten="none", asi_file=None):

        self.name = name
        self.type = mod_type
        self.folder = folder
        self.target = target
        self.nexus_url = nexus_url
        self.download_url = download_url
        self.secondary = secondary or []
        self.blacklist = blacklist or []
        self.regex_blacklist = regex_blacklist or []
        self.manual = manual
        self.no_download = no_download
        self.force_download = force_download
        self.prefer_fallback_zip = prefer_fallback_zip
        self.dry_run = dry_run
        self.summary = summary
        self.flatten = flatten
        self.asi_file = asi_file

        self.summary_installed = []
        self.summary_skipped = []

    def is_blacklisted(self, item):
        if item in self.blacklist:
            return True
        for pattern in self.regex_blacklist:
            if fnmatch.fnmatch(item, pattern):
                return True
        return False

    def install(self, api_key, temp_dir, rdr2_path, downloads_dir):
        log("MODCLASS", f"Installing mod: {self.name}", "A")

        # -----------------------------------------
        # EXE MOD SUPPORT (MUST RUN FIRST)
        # -----------------------------------------
        if self.type == "exe":
            install_exe_mod(self, downloads_dir)
            return

        # -----------------------------------------
        # ZIP FALLBACK CHECK
        # -----------------------------------------
        zip_path = find_existing_zip(self.name, downloads_dir)

        # -----------------------------------------
        # FORCE DOWNLOAD OVERRIDES EVERYTHING
        # -----------------------------------------
        if self.force_download and self.nexus_url:
            dummy_path = os.path.join(downloads_dir, "placeholder.tmp")
            result = download_from_nexus(api_key, self.nexus_url, dummy_path)
            zip_path = result if result else None

        # -----------------------------------------
        # If no fallback ZIP or force_download, follow normal logic
        # -----------------------------------------
        if not zip_path or (self.force_download and not self.prefer_fallback_zip):

            def get_zip_path(prompt):
                while True:
                    p = input(prompt).strip('"')
                    if os.path.isfile(p):
                        return p
                    print("File not found.")

            # CUSTOM mods: allow download_url BEFORE drag/drop
            if self.type == "custom" and self.download_url:
                log("MODCLASS", f"Download URL for {self.name}: {self.download_url}", "A")
                log("MODCLASS", f"Opening download page for {self.name}", "A")
                webbrowser.open(self.download_url)

                user_path = get_zip_path(
                    f"Download {self.name}, then drag the ZIP here:\n> "
                )
                zip_path = os.path.join(downloads_dir, os.path.basename(user_path))
                shutil.move(user_path, zip_path)

            # CUSTOM mods with no download_url → manual
            elif self.type == "custom":
                user_path = get_zip_path(f"Drag {self.name} ZIP here:\n> ")
                zip_path = os.path.join(downloads_dir, os.path.basename(user_path))
                shutil.move(user_path, zip_path)

            # ROOT/LML mods with nexus_url
            elif self.type in ("root", "lml") and self.nexus_url and not self.no_download:

                # NEW: use returned Nexus path directly
                dummy_path = os.path.join(downloads_dir, "placeholder.tmp")
                result = download_from_nexus(api_key, self.nexus_url, dummy_path)

                if result:
                    zip_path = result
                else:
                    # fallback to manual drag/drop
                    user_path = get_zip_path(f"Drag {self.name} ZIP here:\n> ")
                    zip_path = os.path.join(downloads_dir, os.path.basename(user_path))
                    shutil.move(user_path, zip_path)

            # ANY mod with download_url
            elif self.download_url:
                log("MODCLASS", f"Download URL for {self.name}: {self.download_url}", "A")
                log("MODCLASS", f"Opening download page for {self.name}", "A")
                webbrowser.open(self.download_url)

                user_path = get_zip_path(
                    f"Download {self.name}, then drag the ZIP here:\n> "
                )
                zip_path = os.path.join(downloads_dir, os.path.basename(user_path))
                shutil.move(user_path, zip_path)

            # Final fallback
            else:
                user_path = get_zip_path(f"Drag {self.name} ZIP here:\n> ")
                zip_path = os.path.join(downloads_dir, os.path.basename(user_path))
                shutil.move(user_path, zip_path)

        # -----------------------------------------
        # Extract ZIP (now via extract_archive)
        # -----------------------------------------
        zip_base = os.path.splitext(os.path.basename(zip_path))[0]
        extract_path = os.path.join(temp_dir, zip_base)

        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        os.makedirs(extract_path, exist_ok=True)

        extract_archive(zip_path, extract_path)

        # -----------------------------------------
        # DRY RUN
        # -----------------------------------------
        if self.dry_run:
            log("MODCLASS", f"DRY RUN: Would install from {extract_path}", "A")
            return

        # -----------------------------------------
        # Install based on mod type
        # -----------------------------------------
        if self.type == "custom":
            if self.secondary:
                install_secondary(extract_path, rdr2_path, self.secondary, self.type)
            return

        elif self.type == "lml":
            install_lml_hybrid(
                extract_path,
                rdr2_path,
                folder=self.folder,
                blacklist=self.blacklist,
                regex_blacklist=self.regex_blacklist,
                flatten=self.flatten,
                asi_file=self.asi_file,
            )

        elif self.type == "root":
            install_root_flattened(
                extract_path,
                rdr2_path,
                blacklist=self.blacklist,
                regex_blacklist=self.regex_blacklist,
                flatten=self.flatten,
            )

        else:
            log("MODCLASS", f"Unknown mod type '{self.type}', skipping.", "A")
            return

        # -----------------------------------------
        # Secondary installs
        # -----------------------------------------
        if self.secondary and self.type != "custom":
            install_secondary(extract_path, rdr2_path, self.secondary, self.type)

        # -----------------------------------------
        # SUMMARY
        # -----------------------------------------
        if self.summary:
            print("\n===== INSTALL SUMMARY =====")
            for item in self.summary_installed:
                print(f"Installed: {item}")
            for item in self.summary_skipped:
                print(f"Skipped: {item}")
            print("===========================\n")