import os
import requests
from utils import log

API_KEY_FILE = "last_api_key.txt"
RDR2_PATH_FILE = "last_rdr2_path.txt"

# -------------------------------
# SAVE / LOAD RDR2 PATH
# -------------------------------
def load_saved_rdr2_path():
    if os.path.exists(RDR2_PATH_FILE):
        try:
            with open(RDR2_PATH_FILE, "r", encoding="utf-8") as f:
                path = f.read().strip()
                if path:
                    log("PATHS", f"Loaded saved RDR2 path: {path}", "B")
                    return path
        except:
            log("PATHS", "Failed to load saved RDR2 path.", "C")
    return None

def save_rdr2_path(path):
    try:
        with open(RDR2_PATH_FILE, "w", encoding="utf-8") as f:
            f.write(path)
        log("PATHS", f"Saved RDR2 path: {path}", "B")
    except:
        log("PATHS", "Could not save RDR2 path.", "A")

def validate_rdr2_path(path):
    if not os.path.exists(path):
        log("PATHS", "Path does not exist.", "A")
        return False
    if not os.path.exists(os.path.join(path, "RDR2.exe")):
        log("PATHS", "RDR2.exe not found in path.", "A")
        return False
    return True

def ask_rdr2_path():
    saved = load_saved_rdr2_path()
    if saved and validate_rdr2_path(saved):
        print("\nPreviously used RDR2 path found:")
        print(saved)
        choice = input("Use this path again? (Y/N): ").strip().lower()
        if choice == "y":
            return saved

    while True:
        path = input("Enter your RDR2 install path:\n> ").strip('"')
        if validate_rdr2_path(path):
            save_rdr2_path(path)
            return path

# -------------------------------
# SAVE / LOAD API KEY
# -------------------------------
def load_saved_api_key():
    if os.path.exists(API_KEY_FILE):
        try:
            with open(API_KEY_FILE, "r", encoding="utf-8") as f:
                key = f.read().strip()
                if len(key) > 6:
                    log("PATHS", "Loaded saved Nexus API key.", "B")
                    return key
        except:
            log("PATHS", "Failed to load saved API key.", "C")
    return None

def save_api_key(key):
    try:
        with open(API_KEY_FILE, "w", encoding="utf-8") as f:
            f.write(key)
        log("PATHS", "Saved Nexus API key.", "B")
    except:
        log("PATHS", "Could not save API key.", "A")

def ask_nexus_api():
    saved = load_saved_api_key()

    if saved:
        last6 = saved[-6:]
        print("\nA previously used Nexus API key was found.")
        print(f"Last 6 digits: ******{last6}")
        choice = input("Use this key again? (Y/N): ").strip().lower()
        if choice == "y":
            return saved

    print("\nIf you have a Nexus Mods API key, enter it below.")
    print("Leave blank to skip Nexus auto-download.\n")

    api_key = input("Enter your Nexus API Key (or press Enter to skip):\n> ").strip()

    if not api_key:
        print("⚠ No Nexus API key provided. Nexus auto-download will be skipped.")
        return None

    headers = {"apikey": api_key}
    url = "https://api.nexusmods.com/v1/users/validate.json"

    try:
        r = requests.get(url, headers=headers, timeout=15)
    except Exception as e:
        print(f"❌ Could not verify API key: {e}")
        return None

    if r.status_code == 200:
        print("✅ Nexus API key is valid.")
        save_api_key(api_key)
        return api_key
    else:
        print(f"❌ API key invalid (status {r.status_code}).")
        return None