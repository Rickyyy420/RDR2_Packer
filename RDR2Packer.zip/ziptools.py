import os
import shutil
import zipfile
import requests
import patoolib
import time
from utils import log, normalize

# -------------------------------
# ZIP / ARCHIVE FALLBACK SYSTEM
# -------------------------------
def find_existing_zip(mod_name, downloads_dir):
    mod_key = normalize(mod_name)
    log("ZIPTOOLS", f"Searching for existing archive for: {mod_name}", "B")

    for file in os.listdir(downloads_dir):
        lower = file.lower()
        if lower.endswith((".zip", ".rar", ".7z", ".tar", ".gz", ".bz2")):
            zip_key = normalize(os.path.splitext(file)[0])
            log("ZIPTOOLS", f"Comparing {mod_key} to {zip_key}", "C")

            if mod_key in zip_key or zip_key in mod_key:
                found = os.path.join(downloads_dir, file)
                log("ZIPTOOLS", f"Match found: {found}", "B")
                return found

    log("ZIPTOOLS", "No matching archive found.", "A")
    return None

# -------------------------------
# FANCY DOWNLOAD WITH PROGRESS BAR
# -------------------------------
def download_from_url(url, save_path):
    log("ZIPTOOLS", f"Downloading from URL: {url}", "B")

    try:
        with requests.get(url, stream=True) as r:
            r.raise_for_status()

            total = int(r.headers.get("content-length", 0))
            downloaded = 0
            start_time = time.time()

            bar_length = 30  # visual bar length

            with open(save_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)

                        # Percent
                        percent = downloaded / total if total > 0 else 0

                        # Bar
                        filled = int(bar_length * percent)
                        bar = "█" * filled + "░" * (bar_length - filled)

                        # Speed (MB/s)
                        elapsed = time.time() - start_time
                        speed = (downloaded / 1024 / 1024) / elapsed if elapsed > 0 else 0

                        # ETA
                        if speed > 0 and total > 0:
                            remaining = total - downloaded
                            eta_seconds = remaining / (speed * 1024 * 1024)
                            eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
                        else:
                            eta = "--:--"

                        # Single-line progress
                        print(
                            f"\r[ZIPTOOLS:B] [{bar}] {int(percent*100)}%  "
                            f"{speed:.2f} MB/s  ETA {eta}",
                            end="",
                            flush=True
                        )

        print()  # newline after finishing
        log("ZIPTOOLS", f"Downloaded to {save_path}", "A")
        return save_path

    except Exception as e:
        print()  # clean newline on error
        log("ZIPTOOLS", f"Direct download failed: {e}", "B")
        return None

# -------------------------------
# UNIVERSAL ARCHIVE EXTRACTION (FANCY)
# -------------------------------
def extract_archive(path, extract_to):
    ext = os.path.splitext(path)[1].lower()
    log("ZIPTOOLS", f"Extracting {path} to {extract_to}", "B")

    # -----------------------------------------
    # ZIP extraction with progress bar
    # -----------------------------------------
    if ext == ".zip":
        try:
            with zipfile.ZipFile(path, 'r') as zip_ref:
                file_list = zip_ref.infolist()
                total_size = sum(f.file_size for f in file_list)
                extracted = 0
                start_time = time.time()
                bar_length = 30

                for f in file_list:
                    zip_ref.extract(f, extract_to)
                    extracted += f.file_size

                    # Percent
                    percent = extracted / total_size if total_size > 0 else 0

                    # Bar
                    filled = int(bar_length * percent)
                    bar = "█" * filled + "░" * (bar_length - filled)

                    # Speed (MB/s)
                    elapsed = time.time() - start_time
                    speed = (extracted / 1024 / 1024) / elapsed if elapsed > 0 else 0

                    # ETA
                    if speed > 0 and total_size > 0:
                        remaining = total_size - extracted
                        eta_seconds = remaining / (speed * 1024 * 1024)
                        eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
                    else:
                        eta = "--:--"

                    print(
                        f"\r[ZIPTOOLS:B] Extracting [{bar}] {int(percent*100)}%  "
                        f"{speed:.2f} MB/s  ETA {eta}",
                        end="",
                        flush=True
                    )

            print()
            log("ZIPTOOLS", "ZIP extraction complete.", "A")
        except Exception as e:
            print()
            log("ZIPTOOLS", f"ZIP extraction failed: {e}", "A")
        return

    # -----------------------------------------
    # patool extraction with simulated progress bar
    # -----------------------------------------
    try:
        # Start extraction
        patoolib.extract_archive(path, outdir=extract_to, verbosity=-1)

        # After extraction, measure total size
        total_size = 0
        for root, dirs, files in os.walk(extract_to):
            for f in files:
                fp = os.path.join(root, f)
                total_size += os.path.getsize(fp)

        # Simulated progress
        extracted = 0
        start_time = time.time()
        bar_length = 30

        for root, dirs, files in os.walk(extract_to):
            for f in files:
                fp = os.path.join(root, f)
                size = os.path.getsize(fp)
                extracted += size

                percent = extracted / total_size if total_size > 0 else 0
                filled = int(bar_length * percent)
                bar = "█" * filled + "░" * (bar_length - filled)

                elapsed = time.time() - start_time
                speed = (extracted / 1024 / 1024) / elapsed if elapsed > 0 else 0

                if speed > 0 and total_size > 0:
                    remaining = total_size - extracted
                    eta_seconds = remaining / (speed * 1024 * 1024)
                    eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
                else:
                    eta = "--:--"

                print(
                    f"\r[ZIPTOOLS:B] Extracting [{bar}] {int(percent*100)}%  "
                    f"{speed:.2f} MB/s  ETA {eta}",
                    end="",
                    flush=True
                )

        print()
        log("ZIPTOOLS", "Archive extraction complete.", "A")

    except Exception as e:
        print()
        log("ZIPTOOLS", f"Archive extraction failed: {e}", "A")

# -------------------------------
# NEXUS API HELPERS
# -------------------------------
NEXUS_API_BASE = "https://api.nexusmods.com/v1"

def nexus_headers(api_key):
    return {
        "apikey": api_key,
        "Accept": "application/json",
    }

def parse_nexus_mod_info(nexus_url):
    try:
        clean = nexus_url.split("?")[0]
        parts = clean.split("/")
        game_domain = parts[3]
        mod_id = int(parts[5])
        return game_domain, mod_id
    except Exception as e:
        raise ValueError(f"Could not parse Nexus URL: {nexus_url}") from e

def nexus_get_file_list(api_key, game_domain, mod_id):
    url = f"{NEXUS_API_BASE}/games/{game_domain}/mods/{mod_id}/files.json"
    log("ZIPTOOLS", f"Fetching Nexus file list: {url}", "B")
    r = requests.get(url, headers=nexus_headers(api_key))
    r.raise_for_status()
    return r.json()

def nexus_pick_main_file(file_list):
    files = file_list.get("files", [])
    for f in files:
        category = f.get("category_name") or ""
        if category.upper() == "MAIN":
            return f["file_id"]
    if files:
        return files[0]["file_id"]
    return None

def nexus_get_download_link(api_key, game_domain, mod_id, file_id):
    url = f"{NEXUS_API_BASE}/games/{game_domain}/mods/{mod_id}/files/{file_id}/download_link.json"
    log("ZIPTOOLS", f"Fetching Nexus download link: {url}", "B")
    r = requests.get(url, headers=nexus_headers(api_key))
    r.raise_for_status()
    data = r.json()
    if not data:
        raise RuntimeError("No download mirrors returned by Nexus.")
    return data[0]["URI"]

def download_from_nexus(api_key, nexus_url, save_path):
    try:
        game_domain, mod_id = parse_nexus_mod_info(nexus_url)
        log("ZIPTOOLS", f"Nexus mod parsed: game={game_domain}, mod_id={mod_id}", "A")

        file_list = nexus_get_file_list(api_key, game_domain, mod_id)
        file_id = nexus_pick_main_file(file_list)
        if not file_id:
            raise RuntimeError("No downloadable files found for this Nexus mod.")

        log("ZIPTOOLS", f"Selected Nexus file ID: {file_id}", "A")
        download_url = nexus_get_download_link(api_key, game_domain, mod_id, file_id)

        # FIX: Return the REAL downloaded file path
        real_name = os.path.basename(download_url.split("?")[0])
        fixed_path = os.path.join(os.path.dirname(save_path), real_name)

        result = download_from_url(download_url, fixed_path)
        return result

    except Exception as e:
        log("ZIPTOOLS", f"Nexus API failed: {e}", "B")
        return None