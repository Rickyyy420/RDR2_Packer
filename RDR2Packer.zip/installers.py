import os
import shutil
import fnmatch
from utils import log


def _is_blacklisted(name, blacklist, regex_blacklist):
    if name in blacklist:
        return True
    for pattern in regex_blacklist:
        if fnmatch.fnmatch(name, pattern):
            return True
    return False


def _ensure_parent_dir(path):
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)


def _flatten_mode_top(base_dir, dst_root, blacklist, regex_blacklist, exclude_paths=None):
    exclude_paths = exclude_paths or []

    for item in os.listdir(base_dir):
        src_item = os.path.join(base_dir, item)
        if any(os.path.commonpath([src_item, ex]) == ex for ex in exclude_paths):
            continue
        if _is_blacklisted(item, blacklist, regex_blacklist):
            log("INSTALLER-FLAT", f"Skipping blacklisted item (top): {item}", "B")
            continue

        if os.path.isfile(src_item):
            dst_item = os.path.join(dst_root, item)
            if os.path.exists(dst_item):
                if os.path.isdir(dst_item):
                    shutil.rmtree(dst_item)
                else:
                    os.remove(dst_item)
            _ensure_parent_dir(dst_item)
            shutil.move(src_item, dst_item)
            log("INSTALLER-FLAT", f"Moved top-level file to root: {item}", "A")

        elif os.path.isdir(src_item):
            for sub in os.listdir(src_item):
                sub_src = os.path.join(src_item, sub)
                if _is_blacklisted(sub, blacklist, regex_blacklist):
                    log("INSTALLER-FLAT", f"Skipping blacklisted sub-item (top): {sub}", "B")
                    continue
                dst_item = os.path.join(dst_root, sub)
                if os.path.exists(dst_item):
                    if os.path.isdir(dst_item):
                        shutil.rmtree(dst_item)
                    else:
                        os.remove(dst_item)
                _ensure_parent_dir(dst_item)
                shutil.move(sub_src, dst_item)
                log("INSTALLER-FLAT", f"Moved top-level folder content to root: {sub}", "A")


def _flatten_mode_all(base_dir, dst_root, blacklist, regex_blacklist, exclude_paths=None):
    exclude_paths = exclude_paths or []
    files_to_move = []

    for root, dirs, files in os.walk(base_dir):
        if any(os.path.commonpath([root, ex]) == ex for ex in exclude_paths):
            continue
        for f in files:
            if _is_blacklisted(f, blacklist, regex_blacklist):
                log("INSTALLER-FLAT", f"Skipping blacklisted file (all): {f}", "B")
                continue
            src_file = os.path.join(root, f)
            files_to_move.append(src_file)

    for src_file in files_to_move:
        rel_name = os.path.basename(src_file)
        dst_file = os.path.join(dst_root, rel_name)
        if os.path.exists(dst_file):
            if os.path.isdir(dst_file):
                shutil.rmtree(dst_file)
            else:
                os.remove(dst_file)
        _ensure_parent_dir(dst_file)
        shutil.move(src_file, dst_file)
        log("INSTALLER-FLAT", f"Flattened file to root (all): {rel_name}", "A")


def _flatten_mode_list(base_dir, dst_root, folders, blacklist, regex_blacklist, exclude_paths=None):
    exclude_paths = exclude_paths or []
    target_dirs = []

    for root, dirs, files in os.walk(base_dir):
        if any(os.path.commonpath([root, ex]) == ex for ex in exclude_paths):
            continue
        for d in dirs:
            if d in folders:
                target_dirs.append(os.path.join(root, d))

    for tdir in target_dirs:
        for root, dirs, files in os.walk(tdir):
            if any(os.path.commonpath([root, ex]) == ex for ex in exclude_paths):
                continue
            for f in files:
                if _is_blacklisted(f, blacklist, regex_blacklist):
                    log("INSTALLER-FLAT", f"Skipping blacklisted file (list): {f}", "B")
                    continue
                src_file = os.path.join(root, f)
                dst_file = os.path.join(dst_root, os.path.basename(f))
                if os.path.exists(dst_file):
                    if os.path.isdir(dst_file):
                        shutil.rmtree(dst_file)
                    else:
                        os.remove(dst_file)
                _ensure_parent_dir(dst_file)
                shutil.move(src_file, dst_file)
                log("INSTALLER-FLAT", f"Flattened listed folder file: {f}", "A")


def _move_preserving_structure(base_dir, dst_root, blacklist, regex_blacklist, exclude_paths=None):
    exclude_paths = exclude_paths or []

    for item in os.listdir(base_dir):
        src_item = os.path.join(base_dir, item)
        if any(os.path.commonpath([src_item, ex]) == ex for ex in exclude_paths):
            continue
        if _is_blacklisted(item, blacklist, regex_blacklist):
            log("INSTALLER-ROOT", f"Skipping blacklisted item: {item}", "B")
            continue

        dst_item = os.path.join(dst_root, item)
        if os.path.exists(dst_item):
            if os.path.isdir(dst_item):
                shutil.rmtree(dst_item)
            else:
                os.remove(dst_item)
        _ensure_parent_dir(dst_item)
        shutil.move(src_item, dst_item)
        log("INSTALLER-ROOT", f"Moved item preserving structure: {item}", "A")


def install_root_flattened(
    extract_path,
    rdr2_path,
    blacklist=None,
    regex_blacklist=None,
    flatten="none",
    exclude_paths=None,
):
    blacklist = blacklist or []
    regex_blacklist = regex_blacklist or []
    exclude_paths = exclude_paths or []

    log("INSTALLER-ROOT", f"Installing ROOT mod with flatten='{flatten}'", "A")

    if flatten == "none":
        _move_preserving_structure(extract_path, rdr2_path, blacklist, regex_blacklist, exclude_paths)
    elif flatten == "top":
        _flatten_mode_top(extract_path, rdr2_path, blacklist, regex_blacklist, exclude_paths)
    elif flatten == "all":
        _flatten_mode_all(extract_path, rdr2_path, blacklist, regex_blacklist, exclude_paths)
    elif isinstance(flatten, list):
        _flatten_mode_list(extract_path, rdr2_path, flatten, blacklist, regex_blacklist, exclude_paths)
        _move_preserving_structure(extract_path, rdr2_path, blacklist, regex_blacklist, exclude_paths)
    else:
        log("INSTALLER-ROOT", f"Unknown flatten mode '{flatten}', defaulting to 'none'", "B")
        _move_preserving_structure(extract_path, rdr2_path, blacklist, regex_blacklist, exclude_paths)


# ============================================================
# ⭐ UNIVERSAL LML DETECTION (supports ALL formats)
# ============================================================
def _find_lml_folder(extract_path, explicit_folder=None):
    """
    Locate an LML mod folder. Supports:
    - explicit folder containing mod.xml or xml/meta files
    - explicit folder containing an lml/ subfolder
    - top-level lml/ folder
    - any folder that itself looks like an LML mod (mod.xml or xml/meta)
    - any nested lml/ folder
    """

    # 1) Explicit folder provided
    if explicit_folder:
        base = os.path.join(extract_path, explicit_folder)
        if os.path.isdir(base):
            contents = os.listdir(base)

            # Folder IS the LML mod
            if ("mod.xml" in contents) or any(f.endswith(".xml") for f in contents):
                return base

            # Folder contains an lml/ subfolder
            for root, dirs, files in os.walk(base):
                for d in dirs:
                    if d.lower() == "lml":
                        return os.path.join(root, d)

    # 2) Top-level lml/
    for item in os.listdir(extract_path):
        if item.lower() == "lml":
            candidate = os.path.join(extract_path, item)
            if os.path.isdir(candidate):
                return candidate

    # 3) Any folder that looks like an LML mod
    for item in os.listdir(extract_path):
        candidate = os.path.join(extract_path, item)
        if os.path.isdir(candidate):
            contents = os.listdir(candidate)
            if ("mod.xml" in contents) or any(f.endswith(".xml") for f in contents):
                return candidate

    # 4) Nested lml/
    for root, dirs, files in os.walk(extract_path):
        for d in dirs:
            if d.lower() == "lml":
                return os.path.join(root, d)

    return None


# ============================================================
# ⭐ FIXED: PRESERVE FOLDER‑IS‑MOD, BUT NOT CLASSIC LML
# ============================================================
def install_lml_hybrid(
    extract_path,
    rdr2_path,
    folder=None,
    blacklist=None,
    regex_blacklist=None,
    flatten="none",
    asi_file=None,
):
    blacklist = blacklist or []
    regex_blacklist = regex_blacklist or []

    log("INSTALLER-LML", f"Installing LML hybrid with flatten='{flatten}'", "A")

    # 1) Locate LML folder
    lml_folder = _find_lml_folder(extract_path, folder)
    if not lml_folder:
        log("INSTALLER-LML", "LML folder not found. Specify 'folder' in JSON if needed.", "A")
        return

    dst_lml_base = os.path.join(rdr2_path, "lml")
    os.makedirs(dst_lml_base, exist_ok=True)

    folder_name = os.path.basename(lml_folder)

    # ⭐ CASE 1: Classic LML folder (folder name == "lml")
    if folder_name.lower() == "lml":
        for item in os.listdir(lml_folder):
            if _is_blacklisted(item, blacklist, regex_blacklist):
                continue

            src_item = os.path.join(lml_folder, item)
            dst_item = os.path.join(dst_lml_base, item)

            if os.path.exists(dst_item):
                if os.path.isdir(dst_item):
                    shutil.rmtree(dst_item)
                else:
                    os.remove(dst_item)

            _ensure_parent_dir(dst_item)
            shutil.move(src_item, dst_item)
            log("INSTALLER-LML", f"Installed LML item: {item}", "A")

        dst_folder = dst_lml_base  # for exclude_paths

    # ⭐ CASE 2: Folder‑is‑the‑mod (VACISs Wildlife)
    else:
        dst_folder = os.path.join(dst_lml_base, folder_name)

        if os.path.exists(dst_folder):
            shutil.rmtree(dst_folder)

        shutil.move(lml_folder, dst_folder)
        log("INSTALLER-LML", f"Installed LML folder: {folder_name}", "A")

    # 3) ASI extraction
    asi_extracted = False
    asi_parent = None

    if asi_file:
        for root, dirs, files in os.walk(extract_path):
            if asi_file in files:
                src_asi = os.path.join(root, asi_file)
                dst_asi = os.path.join(rdr2_path, asi_file)

                if os.path.exists(dst_asi):
                    os.remove(dst_asi)

                shutil.move(src_asi, dst_asi)
                log("INSTALLER-ROOT", f"Installed ASI file: {asi_file}", "A")

                asi_extracted = True
                asi_parent = root
                break

        if not asi_extracted:
            log("INSTALLER-ROOT", f"ASI file '{asi_file}' not found in archive.", "B")

    # 4) Install remaining root files
    exclude_paths = [dst_folder]
    if asi_parent:
        exclude_paths.append(asi_parent)

    install_root_flattened(
        extract_path,
        rdr2_path,
        blacklist=blacklist,
        regex_blacklist=regex_blacklist,
        flatten=flatten,
        exclude_paths=exclude_paths,
    )


def install_secondary(extract_dir, rdr2_path, secondary_list, mod_type="custom"):
    for entry in secondary_list:
        folder = entry.get("folder")
        target = entry.get("target", "root")

        log("INSTALLER-SECONDARY", f"Searching for secondary folder: {folder}", "B")

        src_folder = None
        for root_dir, dirs, files in os.walk(extract_dir):
            for d in dirs:
                if d == folder:
                    src_folder = os.path.join(root_dir, d)
                    break
            if src_folder:
                break

        if not src_folder:
            log("INSTALLER-SECONDARY", f"Folder not found: {folder}", "A")
            continue

        dst_base = rdr2_path if target == "root" else os.path.join(rdr2_path, "lml")
        os.makedirs(dst_base, exist_ok=True)

        if mod_type == "custom":
            for item in os.listdir(src_folder):
                src_item = os.path.join(src_folder, item)
                dst_item = os.path.join(dst_base, item)

                if os.path.isdir(src_item):
                    if os.path.exists(dst_item):
                        shutil.rmtree(dst_item)
                    shutil.move(src_item, dst_item)
                else:
                    if os.path.exists(dst_item):
                        os.remove(dst_item)
                    shutil.move(src_item, dst_item)

            log("INSTALLER-SECONDARY", f"Installed contents of {folder} (flattened)", "A")
        else:
            dst_folder = os.path.join(dst_base, folder)
            if os.path.exists(dst_folder):
                shutil.rmtree(dst_folder)
            shutil.move(src_folder, dst_folder)
            log("INSTALLER-SECONDARY", f"Installed folder {folder}", "A")