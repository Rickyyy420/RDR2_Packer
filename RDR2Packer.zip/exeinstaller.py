import os
import webbrowser
from utils import log


def install_exe_mod(mod, downloads_dir):
    """
    Handles installation of EXE-based mods such as ReShade.
    This bypasses all ZIP logic and provides a clean, dedicated workflow.
    """

    # -----------------------------------------
    # PRINT + OPEN DOWNLOAD PAGE
    # -----------------------------------------
    if mod.download_url:
        log("EXE", f"Download URL for {mod.name}: {mod.download_url}", "A")
        log("EXE", f"Opening download page for {mod.name}", "A")
        webbrowser.open(mod.download_url)
    else:
        log("EXE", f"No download_url provided for {mod.name}.", "A")

    # -----------------------------------------
    # PROMPT USER FOR EXE FILE
    # -----------------------------------------
    while True:
        exe_path = input(
            f"Download {mod.name}, then drag the EXE file here:\n> "
        ).strip('"')

        if os.path.isfile(exe_path) and exe_path.lower().endswith(".exe"):
            break

        print("EXE not found. Please try again.")

    # -----------------------------------------
    # LAUNCH EXE INSTALLER
    # -----------------------------------------
    log("EXE", f"Launching installer for {mod.name}", "A")
    os.startfile(exe_path)

    log("EXE", f"{mod.name} installer launched successfully.", "A")