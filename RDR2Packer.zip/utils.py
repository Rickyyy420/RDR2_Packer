import json
import re

# Load config once
with open("config.json", "r") as f:
    CONFIG = json.load(f)

LOG_LEVEL = CONFIG.get("log_level", "B").upper()

# Level priority
LEVELS = {
    "A": 1,   # minimal
    "B": 2,   # verbose
    "C": 3    # developer mode
}

def log(module, message, level="A"):
    """Prints a message if its level is <= current log level."""
    if LEVELS[level] <= LEVELS.get(LOG_LEVEL, 2):
        print(f"[{module}:{level}] {message}")

def normalize(s):
    """Normalize strings for loose ZIP matching."""
    return re.sub(r'[^a-z0-9]', '', s.lower())
