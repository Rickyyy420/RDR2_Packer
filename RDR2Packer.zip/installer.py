import os
import shutil
import json

from paths import ask_rdr2_path, ask_nexus_api
from modclass import Mod
from utils import log

def main():
    print("====================================")
    print("RDR2 Modpack Installer")
    print("====================================")

    rdr2_path = ask_rdr2_path()
    api_key = ask_nexus_api()

    temp_dir = os.path.join(os.getcwd(), "_temp")
    os.makedirs(temp_dir, exist_ok=True)

    downloads_dir = os.path.join(rdr2_path, "downloads")
    os.makedirs(downloads_dir, exist_ok=True)

    # Track installed mods
    installed_mods = []

    # ----------------------------
    # Install mainmods.json
    # ----------------------------
    with open("mainmods.json", "r") as f:
        mainmods = json.load(f)["mainmods"]

    for m in mainmods:
        mod = Mod(
            name=m["name"],
            mod_type=m["type"],
            folder=m.get("folder"),
            target=m.get("target"),
            nexus_url=m.get("nexus_url"),
            download_url=m.get("download_url"),
            secondary=m.get("secondary"),
            blacklist=m.get("blacklist"),
            regex_blacklist=m.get("regex_blacklist"),
            manual=m.get("manual", False),
            no_download=m.get("no_download", False),
            force_download=m.get("force_download", False),
            prefer_fallback_zip=m.get("prefer_fallback_zip", False),
            dry_run=m.get("dry_run", False),
            summary=m.get("summary", False),
            flatten=m.get("flatten", "none"),
            asi_file=m.get("asi_file"),
        )
        mod.install(api_key, temp_dir, rdr2_path, downloads_dir)
        log("INSTALLER", f"{mod.name} installed successfully.", "A")
        installed_mods.append(mod.name)

    # ----------------------------
    # Install pack.json
    # ----------------------------
    with open("pack.json", "r") as f:
        pack = json.load(f)["mods"]

    for m in pack:
        if "name" not in m:
            continue
        mod = Mod(
            name=m["name"],
            mod_type=m["type"],
            folder=m.get("folder"),
            target=m.get("target"),
            nexus_url=m.get("nexus_url"),
            download_url=m.get("download_url"),
            secondary=m.get("secondary"),
            blacklist=m.get("blacklist"),
            regex_blacklist=m.get("regex_blacklist"),
            manual=m.get("manual", False),
            no_download=m.get("no_download", False),
            force_download=m.get("force_download", False),
            prefer_fallback_zip=m.get("prefer_fallback_zip", False),
            dry_run=m.get("dry_run", False),
            summary=m.get("summary", False),
            flatten=m.get("flatten", "none"),
            asi_file=m.get("asi_file"),
        )
        mod.install(api_key, temp_dir, rdr2_path, downloads_dir)
        log("INSTALLER", f"{mod.name} installed successfully.", "A")
        installed_mods.append(mod.name)

    # Cleanup
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

    # ----------------------------
    # FINAL MODLIST SUMMARY
    # ----------------------------
    print("\n====================================")
    print(f" FINAL MOD LIST ({len(installed_mods)} installed)")
    print("====================================\n")

    for i, mod_name in enumerate(installed_mods, start=1):
        print(f"{i}. {mod_name}")

    print("\n====================================")
    print("All mods installed successfully.")
    print("====================================\n")

    input("Press Enter to exit...")

if __name__ == "__main__":
    main()